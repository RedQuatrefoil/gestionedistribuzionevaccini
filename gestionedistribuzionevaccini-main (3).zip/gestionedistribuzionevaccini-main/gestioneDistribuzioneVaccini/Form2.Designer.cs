﻿namespace gestioneDistribuzioneVaccini
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.listvaccbtn = new System.Windows.Forms.Button();
            this.storvaccbtn = new System.Windows.Forms.Button();
            this.retbtn = new System.Windows.Forms.Button();
            this.creazbtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(672, 74);
            this.label1.TabIndex = 4;
            this.label1.Text = "Vaccine distributor";
            // 
            // listvaccbtn
            // 
            this.listvaccbtn.BackColor = System.Drawing.Color.SkyBlue;
            this.listvaccbtn.ForeColor = System.Drawing.Color.Blue;
            this.listvaccbtn.Location = new System.Drawing.Point(307, 178);
            this.listvaccbtn.Name = "listvaccbtn";
            this.listvaccbtn.Size = new System.Drawing.Size(166, 23);
            this.listvaccbtn.TabIndex = 5;
            this.listvaccbtn.Text = "Lista di vaccinazione e info";
            this.listvaccbtn.UseVisualStyleBackColor = false;
            this.listvaccbtn.Click += new System.EventHandler(this.listvaccbtn_Click);
            // 
            // storvaccbtn
            // 
            this.storvaccbtn.BackColor = System.Drawing.Color.SkyBlue;
            this.storvaccbtn.ForeColor = System.Drawing.Color.Blue;
            this.storvaccbtn.Location = new System.Drawing.Point(93, 329);
            this.storvaccbtn.Name = "storvaccbtn";
            this.storvaccbtn.Size = new System.Drawing.Size(140, 23);
            this.storvaccbtn.TabIndex = 6;
            this.storvaccbtn.Text = "Storico di vaccinazione";
            this.storvaccbtn.UseVisualStyleBackColor = false;
            this.storvaccbtn.Click += new System.EventHandler(this.storvaccbtn_Click);
            // 
            // retbtn
            // 
            this.retbtn.BackColor = System.Drawing.Color.SkyBlue;
            this.retbtn.ForeColor = System.Drawing.Color.Blue;
            this.retbtn.Location = new System.Drawing.Point(307, 329);
            this.retbtn.Name = "retbtn";
            this.retbtn.Size = new System.Drawing.Size(166, 23);
            this.retbtn.TabIndex = 7;
            this.retbtn.Text = "Torna al menù principale";
            this.retbtn.UseVisualStyleBackColor = false;
            this.retbtn.Click += new System.EventHandler(this.retbtn_Click);
            // 
            // creazbtn
            // 
            this.creazbtn.BackColor = System.Drawing.Color.SkyBlue;
            this.creazbtn.ForeColor = System.Drawing.Color.Blue;
            this.creazbtn.Location = new System.Drawing.Point(93, 178);
            this.creazbtn.Name = "creazbtn";
            this.creazbtn.Size = new System.Drawing.Size(140, 23);
            this.creazbtn.TabIndex = 3;
            this.creazbtn.Text = "Aggiungi nuovo paziente";
            this.creazbtn.UseVisualStyleBackColor = false;
            this.creazbtn.Click += new System.EventHandler(this.creazbtn_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.retbtn);
            this.Controls.Add(this.storvaccbtn);
            this.Controls.Add(this.listvaccbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.creazbtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Vaccine distributor";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button listvaccbtn;
        private System.Windows.Forms.Button storvaccbtn;
        private System.Windows.Forms.Button retbtn;
        private System.Windows.Forms.Button creazbtn;
    }
}