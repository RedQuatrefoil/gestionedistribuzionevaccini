﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestioneDistribuzioneVaccini
{
    public partial class Form3 : Form
    {
        [Serializable]
        public class Person
        {
            public string name;

            public string surname;

            public int eta;

            public string residenza;

            public string job;

            public bool ipertensione;

            public bool diabete;

            public bool scompcard;

            public bool insren;
        }
        public gestioneDistribuzioneVaccini.Form3.Person[] obje { get; set; }
        public Person[] people = new Person[500];
        public Form3()
        {
            InitializeComponent();
        }

        private void confirmbt_Click(object sender, EventArgs e)
        {
            for (int a = 0; a < people.Length; a++) people[a] = new Person();

            if (obje != null)
                people = obje;

            if (nomebtn.TextLength > 0)//Se il campo di inserimento nome non è vuoto può continuare 
            {
                if (cognomebtn.TextLength > 0)//Se il campo di inserimento cognome non è vuoto può continuare 
                {
                    if (etabtn.TextLength > 0)//Se il campo di inserimento mail non è vuoto può continuare 
                    {
                        if (resbtn.TextLength > 0)//Se il campo di inserimento password non è vuoto può continuare 
                        {
                            if (jobbtn.TextLength > 0)//Se il campo di inserimento password ha più di sette caratteri può continuare 
                            {
                                bool se = false;
                                bool ugual = false;
                                int i = 0, ie = 0;
                                while (se == false && ie < 250)//Cerca il primo posto libero all'interno dell'array
                                {
                                    if (people == null)
                                    {
                                        i = 0;

                                        se = true;
                                    }
                                    else
                                    {
                                        if (people[ie].name == null)
                                        {
                                            i = ie;

                                            se = true;
                                        }
                                        else
                                            ie++;
                                    }
                                }
                                if (ugual == false)
                                {
                                    //Prepara il posto trovato
                                    people[i].name = String.Empty;

                                    people[i].surname = String.Empty;

                                    people[i].residenza = String.Empty;

                                    people[i].job = String.Empty;
                                    //Riempie il posto trovato
                                    people[i].name = nomebtn.Text;

                                    people[i].surname = cognomebtn.Text;

                                    people[i].eta = Convert.ToInt32(etabtn.Text);

                                    people[i].residenza = resbtn.Text;

                                    people[i].job = jobbtn.Text;

                                    if (ipertenscb.Checked == true)
                                        people[i].ipertensione = true;
                                    else
                                        people[i].ipertensione = false;

                                    if (diabetecb.Checked == true)
                                        people[i].diabete = true;
                                    else
                                        people[i].diabete = false;

                                    if (scompcardcb.Checked == true)
                                        people[i].scompcard = true;
                                    else
                                        people[i].scompcard = false;

                                    if (insrencb.Checked == true)
                                        people[i].insren = true;
                                    else
                                        people[i].insren = false;

                                    MessageBox.Show("New account created");

                                    obje = people;
                                    //Resetta la schermata
                                    nomebtn.Text = null;

                                    cognomebtn.Text = null;

                                    etabtn.Text = null;

                                    resbtn.Text = null;

                                    jobbtn.Text = null;

                                    ipertenscb.Checked = false;

                                    diabetecb.Checked = false;

                                    scompcardcb.Checked = false;

                                    insrencb.Checked = false;
                                }
                                else
                                    MessageBox.Show("Professione non indicata");
                            }
                            else
                                MessageBox.Show("Residenza non indicata");
                        }
                        else
                            MessageBox.Show("Età non indicata");
                    }
                    else
                        MessageBox.Show("Surname non indicato");
                }
                else
                    MessageBox.Show("Name non indicato");
            }
        }

        private void returnbt_Click(object sender, EventArgs e)
        {//Passa l'array ottenuto dagli altri form a Form1, nasconde la finestra Account e passa alla finestra Form1
            this.Hide();

            Form1 frm = new Form1();

            frm.save = people;

            frm.ShowDialog();

        }

        private void contbt_Click(object sender, EventArgs e)
        {//Passa l'array ottenuto dagli altri form a Form2, nasconde la finestra Account e passa alla finestra Form2
            this.Hide();

            Form2 frm = new Form2();

            frm.f2Array = people;

            frm.ShowDialog();

        }
    }
}
