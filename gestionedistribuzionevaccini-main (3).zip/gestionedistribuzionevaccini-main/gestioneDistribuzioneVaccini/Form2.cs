﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gestioneDistribuzioneVaccini
{
    public partial class Form2 : Form
    {
        public gestioneDistribuzioneVaccini.Form3.Person[] f2Array { get; set; }
        public Form2()
        {
            InitializeComponent();
        }

        private void creazbtn_Click(object sender, EventArgs e)
        {//Passa l'array ottenuto dagli altri form al form Account, nasconde la finestra Form2 e passa alla finestra Account
            this.Hide();

            Form3 frm = new Form3();

            frm.obje = f2Array;

            frm.ShowDialog();
        }

        private void listvaccbtn_Click(object sender, EventArgs e)
        {//Passa l'array ottenuto dagli altri form al form Purchase, nasconde la finestra Form2 e passa alla finestra Purchase
            this.Hide();

            Form4 frm = new Form4();

            frm.dateArray = f2Array;

            frm.ShowDialog();
        }

        private void storvaccbtn_Click(object sender, EventArgs e)
        {//Passa l'array ottenuto dagli altri form al form Simulation, nasconde la finestra Form2 e passa alla finestra Simulation
            this.Hide();

            Form5 frm = new Form5();

            frm.final = f2Array;

            frm.ShowDialog();
        }

        private void retbtn_Click(object sender, EventArgs e)
        {//Passa l'array ottenuto dagli altri form al form Simulation, nasconde la finestra Form2 e passa alla finestra Simulation
            this.Hide();

            Form1 frm = new Form1();

            frm.save = f2Array;

            frm.ShowDialog();
        }
    }
}
