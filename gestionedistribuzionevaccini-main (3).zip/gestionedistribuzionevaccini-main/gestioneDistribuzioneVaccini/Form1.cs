﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;

namespace gestioneDistribuzioneVaccini
{
    public partial class Form1 : Form
    {
        public gestioneDistribuzioneVaccini.Form3.Person[] save { get; set; }
        public Form1()
        {
            InitializeComponent();
        }

        private void entb_Click(object sender, EventArgs e)
        {
            bool search = false;
            //Cerca se il file di salvataggio esiste
            Console.WriteLine(File.Exists("savingstruct.ext") ? search = true : search = false);
            if (search == true && save == null)//Il file di salvataggio esiste e quindi ne legge il contenuto perchè è la prima volta
            {//Legge il file di salvataggio e passa l'array a Form2, nasconde la finestra Form1 e passa alla finestra Form2
                var stream = new StreamReader("savingstruct.ext");

                var ser = new XmlSerializer(typeof(gestioneDistribuzioneVaccini.Form3.Person[]));

                object obj = ser.Deserialize(stream);

                stream.Close();

                Form3.Person[] newarray = new Form3.Person[5];

                newarray = (Form3.Person[])obj;

                this.Hide();

                Form2 from = new Form2();

                from.f2Array = newarray;

                from.ShowDialog();
            }
            else//Il file non esiste quindi non ci sono salvataggi da leggere oppure non è la prima volta che il programma cerca di leggere il file di salvataggio
            {//Passa l'array ottenuto dagli altri form a Form2, nasconde la finestra Form1 e passa alla finestra Form2
                this.Hide();

                Form2 from = new Form2();

                from.f2Array = save;

                from.ShowDialog();
            }
        }

        private void ewsbt_Click(object sender, EventArgs e)
        {
            DialogResult dialog = new DialogResult();
            //Uscita dal programma senza salvare i cambiamenti di questa sessione
            dialog = MessageBox.Show("Do you want to close without saving?", "Alert!", MessageBoxButtons.YesNo);

            if (dialog == DialogResult.Yes)
                Application.Exit();
        }

        private void easbt_Click(object sender, EventArgs e)
        {
            if (save != null)//Se l'array non è vuoto lo salva su file e poi chiede se uscire dal programma
            {
                var serializer = new XmlSerializer(save.GetType());

                var sw = new StreamWriter("savingstruct.ext");

                serializer.Serialize(sw, save);

                sw.Close();

                DialogResult dialog = new DialogResult();

                dialog = MessageBox.Show("Do you want to close?", "Alert!", MessageBoxButtons.YesNo);

                if (dialog == DialogResult.Yes)
                    Application.Exit();
            }
            else//Se l'array è vuoto chiede se uscire dal programma ma non lo salva
            {
                DialogResult dialog = new DialogResult();

                dialog = MessageBox.Show("Do you want to close?", "Alert!", MessageBoxButtons.YesNo);

                if (dialog == DialogResult.Yes)
                    Application.Exit();
            }
        }
    }
}
